#include "structures.h"

/*void show_program(is_expression_list*);
void show_expression(is_expression*);
void show_infix_expression(is_infix_expression*);
void show_unary_expression(is_unary_expression*);
void show_operator(is_oper);
void printSymbols(ClassTable* table);*/
